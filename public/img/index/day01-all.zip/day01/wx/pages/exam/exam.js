// pages/exam/exam.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
     msg:"文华老师要去出差，去哪了?",
     list:[
       {id:1,addr:"东北"},
       {id:2,addr:"东莞"},
       {id:3,addr:"上海"}]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //wx.showToast({
    //  title:"小程序组件",
    //  icon:"success",
    //  duration:2000
    //})
    var i = 10;
    var j = 11;
    console.log(i+j);
    //ECMA Object
    var now = new Date().toLocaleString();
    console.log(now);
    var reg = /^[0-9]{1,3}$/;
    var num = "123";
    if(reg.test(num)){
      console.log("验证成功");
    }else{
      console.log("验证失败");
    }

    //访问data中数据 this 当前对象
    //console.log(this);
    //console.log(this.data.msg);
    //console.log(this.data.list);
    //this.data.msg = "文华老师回来了!";
    //this.setData({
    //  msg:"文华老师又出差了!"
    //})
    this.show();
  },
  show:function(){
    console.log("显示列表内容");
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})